import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { MOCK_GAMES } from "../constants";

let ai: GoogleGenAI | null = null;
let chatSession: Chat | null = null;

const initializeAI = () => {
  if (!process.env.API_KEY) {
    console.warn("Gemini API Key is missing.");
    return null;
  }
  // Always create a new instance to ensure we pick up any potentially updated keys
  // specifically for features that might require user-selected keys (like Veo)
  ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai;
};

// Helper to check for user-selected API key for premium features (Veo, Pro Image)
export const ensurePremiumApiKey = async (): Promise<boolean> => {
  const win = window as any;
  if (win.aistudio) {
    const hasKey = await win.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await win.aistudio.openSelectKey();
      // Re-check after dialog potentially closes
      return await win.aistudio.hasSelectedApiKey();
    }
    return true;
  }
  // Fallback if not in that specific environment, assume process.env is sufficient
  return !!process.env.API_KEY;
};

const getSystemInstruction = () => {
  const catalogContext = MOCK_GAMES.map(g => 
    `ID: ${g.id}, Title: ${g.title}, Genre: ${g.tags.join(', ')}, Price: $${g.price}, Rating: ${g.rating}/5`
  ).join('\n');

  return `You are Nexus AI, a helpful and knowledgeable gaming assistant.
  Current Store Catalog:
  ${catalogContext}
  Rules:
  1. Prioritize catalog games for recommendations.
  2. Use Google Search for real-world gaming news.
  3. Be concise and enthusiastic.`;
};

// File conversion helper
const fileToPart = async (file: File) => {
  return new Promise<{ inlineData: { data: string; mimeType: string } }>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      resolve({
        inlineData: {
          data: base64String,
          mimeType: file.type
        }
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

interface ServiceResponse {
  text: string;
  sources?: { title: string; uri: string }[];
  media?: { type: 'image' | 'video'; url: string };
}

// 1. Standard Chat
export const chatWithGemini = async (userMessage: string): Promise<ServiceResponse> => {
  const aiInstance = initializeAI();
  if (!aiInstance) return { text: "Offline." };

  try {
    if (!chatSession) {
      chatSession = aiInstance.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
          systemInstruction: getSystemInstruction(),
          tools: [{ googleSearch: {} }]
        }
      });
    }

    const result = await chatSession.sendMessage({ message: userMessage });
    return extractResponse(result);
  } catch (error) {
    console.error("Chat Error:", error);
    return { text: "Connection interrupted." };
  }
};

// 2. Deep Thinking (Complex Queries)
export const chatDeepThink = async (userMessage: string): Promise<ServiceResponse> => {
  const aiInstance = initializeAI();
  if (!aiInstance) return { text: "Offline." };

  try {
    // One-off request for deep thinking, no persistent chat history for this mode to save context window
    const response = await aiInstance.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: userMessage,
      config: {
        thinkingConfig: { thinkingBudget: 32768 } // Max for 3-pro
      }
    });
    return { text: response.text || "I thought hard, but couldn't find an answer." };
  } catch (error) {
    console.error("Think Error:", error);
    return { text: "My neural pathways are overloaded. Try a simpler question." };
  }
};

// 3. Analyze Image
export const analyzeImage = async (file: File, prompt: string): Promise<ServiceResponse> => {
  const aiInstance = initializeAI();
  if (!aiInstance) return { text: "Offline." };

  try {
    const imagePart = await fileToPart(file);
    const response = await aiInstance.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [imagePart, { text: prompt || "Analyze this image." }]
      }
    });
    return { text: response.text || "Analysis complete." };
  } catch (error) {
    console.error("Analysis Error:", error);
    return { text: "Failed to analyze image." };
  }
};

// 4. Generate Image (Nano Banana Pro)
export const generateImage = async (prompt: string, size: '1K' | '2K' | '4K'): Promise<ServiceResponse> => {
  await ensurePremiumApiKey(); // Requirement for Pro Image
  const aiInstance = initializeAI();
  if (!aiInstance) return { text: "Offline." };

  try {
    const response = await aiInstance.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: { imageSize: size }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return {
          text: `Generated ${size} image for: "${prompt}"`,
          media: {
            type: 'image',
            url: `data:image/png;base64,${part.inlineData.data}`
          }
        };
      }
    }
    return { text: "No image generated." };
  } catch (error) {
    console.error("Gen Image Error:", error);
    return { text: "Failed to generate image." };
  }
};

// 5. Edit Image (Nano Banana Flash)
export const editImage = async (file: File, prompt: string): Promise<ServiceResponse> => {
  const aiInstance = initializeAI();
  if (!aiInstance) return { text: "Offline." };

  try {
    const imagePart = await fileToPart(file);
    const response = await aiInstance.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [imagePart, { text: prompt }]
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return {
          text: `Edited image: "${prompt}"`,
          media: {
            type: 'image',
            url: `data:image/png;base64,${part.inlineData.data}`
          }
        };
      }
    }
    return { text: "No edited image returned." };
  } catch (error) {
    console.error("Edit Image Error:", error);
    return { text: "Failed to edit image." };
  }
};

// 6. Animate Image (Veo)
export const animateImage = async (file: File): Promise<ServiceResponse> => {
  await ensurePremiumApiKey(); // Mandatory for Veo
  const aiInstance = initializeAI();
  if (!aiInstance) return { text: "Offline." };

  try {
    const imagePart = await fileToPart(file);
    
    // Using raw bytes for Veo input as per SDK examples
    let operation = await aiInstance.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      image: {
        imageBytes: imagePart.inlineData.data,
        mimeType: imagePart.inlineData.mimeType
      },
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9' // Landscape default
      }
    });

    // Polling
    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      operation = await aiInstance.operations.getVideosOperation({ operation });
    }

    const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (videoUri) {
      // Must append API key for fetch
      const fetchUrl = `${videoUri}&key=${process.env.API_KEY}`;
      return {
        text: "Video generated successfully!",
        media: {
          type: 'video',
          url: fetchUrl
        }
      };
    }
    return { text: "Video generation failed." };
  } catch (error) {
    console.error("Veo Error:", error);
    return { text: "Failed to animate image." };
  }
};

// Helper to extract text and sources from response
const extractResponse = (result: GenerateContentResponse): ServiceResponse => {
  const text = result.text || "No response text.";
  const sources: { title: string; uri: string }[] = [];
  
  if (result.candidates?.[0]?.groundingMetadata?.groundingChunks) {
    result.candidates[0].groundingMetadata.groundingChunks.forEach((chunk: any) => {
      if (chunk.web?.uri && chunk.web?.title) {
        sources.push({ title: chunk.web.title, uri: chunk.web.uri });
      }
    });
  }
  return { text, sources: sources.length > 0 ? sources : undefined };
};