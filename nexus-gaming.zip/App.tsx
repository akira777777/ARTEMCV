import React, { useState, useMemo, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Game, CartItem, ToastMessage, Review } from './types';
import { MOCK_GAMES, MOCK_REVIEWS, CATEGORIES } from './constants';
import { GameCard } from './components/GameCard';
import { CartDrawer } from './components/CartDrawer';
import { AIChatAssistant } from './components/AIChatAssistant';
import { GameDetailsModal } from './components/GameDetailsModal';
import { AboutModal } from './components/AboutModal';
import { ProfileModal } from './components/ProfileModal';
import { Toast } from './components/Toast';
import { GameCardSkeleton } from './components/Skeletons';
import { TrendingRow } from './components/TrendingRow';
import { Newsletter } from './components/Newsletter';
import { Library } from './pages/Library';
import { Community } from './pages/Community';
import { Search, ShoppingBag, Gamepad2, Menu, Ghost, Heart, User, Library as LibraryIcon, Users } from 'lucide-react';

// Wrapper to get location for active tab highlighting
const Navigation: React.FC<{ 
  cartCount: number, 
  wishlistCount: number,
  onOpenCart: () => void,
  onOpenProfile: () => void,
  searchQuery: string,
  setSearchQuery: (q: string) => void
}> = ({ cartCount, wishlistCount, onOpenCart, onOpenProfile, searchQuery, setSearchQuery }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path ? 'text-nexus-accent' : 'text-gray-400 hover:text-white';

  return (
    <nav className="sticky top-0 z-40 bg-nexus-900/80 backdrop-blur-md border-b border-nexus-700">
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-20 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-nexus-accent rounded-lg flex items-center justify-center transform group-hover:rotate-12 transition-transform shadow-[0_0_10px_rgba(0,242,255,0.3)]">
              <Gamepad2 className="text-nexus-900" size={24} />
            </div>
            <span className="text-2xl font-display font-bold tracking-tight text-white">NEXUS</span>
          </Link>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-6">
            <Link to="/" className={`text-sm font-bold uppercase tracking-wide transition-colors ${isActive('/')}`}>Store</Link>
            <Link to="/library" className={`text-sm font-bold uppercase tracking-wide transition-colors ${isActive('/library')}`}>Library</Link>
            <Link to="/community" className={`text-sm font-bold uppercase tracking-wide transition-colors ${isActive('/community')}`}>Community</Link>
          </div>
        </div>

        {/* Desktop Search */}
        <div className="hidden md:flex flex-1 max-w-md mx-8 relative">
          <input
            type="text"
            placeholder="Search games..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-nexus-800 border border-nexus-700 rounded-full py-2 pl-10 pr-4 focus:outline-none focus:border-nexus-accent focus:ring-1 focus:ring-nexus-accent transition-all text-sm text-white"
          />
          <Search className="absolute left-3 top-2.5 text-gray-500" size={18} />
        </div>

        <div className="flex items-center gap-2 md:gap-4">
          {/* User Profile Button - Desktop */}
          <button 
            onClick={onOpenProfile}
            className="hidden md:flex p-2 hover:bg-nexus-800 rounded-full transition-colors text-gray-400 hover:text-white"
            title="User Profile"
          >
            <User size={24} />
          </button>

          <div className="hidden md:flex items-center gap-2 mr-2">
             <button className="p-2 hover:bg-nexus-800 rounded-full transition-colors relative group">
               <Heart className={`text-gray-400 group-hover:text-nexus-danger transition-colors ${wishlistCount > 0 ? 'fill-nexus-danger text-nexus-danger' : ''}`} size={24} />
               {wishlistCount > 0 && (
                 <span className="absolute top-0 right-0 w-4 h-4 bg-nexus-danger text-white text-[10px] font-bold flex items-center justify-center rounded-full">
                   {wishlistCount}
                 </span>
               )}
             </button>
          </div>

          <button 
            onClick={onOpenCart}
            className="relative p-2 hover:bg-nexus-800 rounded-full transition-colors"
          >
            <ShoppingBag className="text-white" size={24} />
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 w-5 h-5 bg-nexus-accent text-nexus-900 text-xs font-bold flex items-center justify-center rounded-full">
                {cartCount}
              </span>
            )}
          </button>
          
          {/* Mobile Menu Button - Would normally open a drawer */}
          <button className="md:hidden p-2">
            <Menu className="text-white" size={24} />
          </button>
        </div>
      </div>
      
      {/* Mobile Tab Bar (Bottom) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-nexus-900 border-t border-nexus-700 p-2 flex justify-around z-50">
        <Link to="/" className={`flex flex-col items-center p-2 ${isActive('/')}`}>
          <Gamepad2 size={20} />
          <span className="text-[10px] mt-1">Store</span>
        </Link>
        <Link to="/library" className={`flex flex-col items-center p-2 ${isActive('/library')}`}>
          <LibraryIcon size={20} />
          <span className="text-[10px] mt-1">Library</span>
        </Link>
        <Link to="/community" className={`flex flex-col items-center p-2 ${isActive('/community')}`}>
          <Users size={20} />
          <span className="text-[10px] mt-1">Community</span>
        </Link>
      </div>
    </nav>
  );
}

const App: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [reviews, setReviews] = useState<Review[]>(MOCK_REVIEWS);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activeGame, setActiveGame] = useState<Game | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  
  // Loading States
  const [isGridLoading, setIsGridLoading] = useState(true);
  const [isDetailsLoading, setIsDetailsLoading] = useState(false);

  // Initial Data Load Simulation
  useEffect(() => {
    const timer = setTimeout(() => setIsGridLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  const addToast = (type: 'success' | 'info' | 'error', message: string) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, type, message }]);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const addToCart = (game: Game) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === game.id);
      if (existing) {
        return prev.map(item => item.id === game.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...game, quantity: 1 }];
    });
    addToast('success', `Added ${game.title} to cart`);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
    addToast('info', 'Removed item from cart');
  };

  const toggleWishlist = (game: Game) => {
    setWishlist(prev => {
      if (prev.includes(game.id)) {
        addToast('info', `Removed ${game.title} from wishlist`);
        return prev.filter(id => id !== game.id);
      } else {
        addToast('success', `Added ${game.title} to wishlist`);
        return [...prev, game.id];
      }
    });
  };

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    // Simulate Fetching
    setIsGridLoading(true);
    setTimeout(() => setIsGridLoading(false), 600);
  };

  const handleViewDetails = (game: Game) => {
    // Open modal immediately to show skeleton
    setActiveGame(game);
    setIsDetailsLoading(true);
    // Simulate API delay
    setTimeout(() => setIsDetailsLoading(false), 800);
  };

  const handleCloseDetails = () => {
    setActiveGame(null);
    setIsDetailsLoading(false);
  };

  const handleAddReview = (gameId: string, reviewData: Omit<Review, 'id' | 'gameId' | 'date'>) => {
    const newReview: Review = {
      id: Date.now().toString(),
      gameId,
      date: new Date().toISOString().split('T')[0],
      ...reviewData
    };
    setReviews(prev => [newReview, ...prev]);
    addToast('success', 'Review submitted successfully!');
  };

  const filteredGames = useMemo(() => {
    return MOCK_GAMES.filter(game => {
      const matchesSearch = game.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || game.tags.includes(selectedCategory);
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const activeGameReviews = useMemo(() => {
    return activeGame ? reviews.filter(r => r.gameId === activeGame.id) : [];
  }, [activeGame, reviews]);

  // Derived trending games (just taking top rated for demo)
  const trendingGames = useMemo(() => {
     return [...MOCK_GAMES].sort((a, b) => b.rating - a.rating).slice(0, 5);
  }, []);

  const Hero = () => (
    <div className="relative h-[500px] w-full overflow-hidden mb-12 rounded-2xl group border border-nexus-700/30">
      <div className="absolute inset-0 bg-gradient-to-r from-nexus-900 to-transparent z-10" />
      <img 
        src="https://image.pollinations.ai/prompt/cyberpunk%20city%20futuristic%20neon%20lights%20rain?width=1600&height=900&nologo=true" 
        alt="Hero" 
        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" 
      />
      <div className="absolute bottom-0 left-0 z-20 p-8 md:p-16 max-w-2xl">
        <span className="inline-block px-3 py-1 bg-nexus-accent text-nexus-900 font-bold rounded mb-4 text-sm tracking-wider animate-pulse-slow">FEATURED DROP</span>
        <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-4 leading-tight drop-shadow-lg">
          CYBER ODYSSEY <span className="text-nexus-accent">2077</span>
        </h1>
        <p className="text-gray-300 text-lg mb-8 line-clamp-2 drop-shadow-md">
          Experience the future of open-world gaming. Immerse yourself in a city that never sleeps, filled with danger and opportunity.
        </p>
        <div className="flex gap-4">
          <button className="bg-white text-nexus-900 hover:bg-nexus-accent px-8 py-3 rounded font-bold text-lg transition-colors">
            Pre-Order Now
          </button>
          <button className="bg-black/50 backdrop-blur border border-white/20 text-white hover:bg-white/10 px-8 py-3 rounded font-bold text-lg transition-colors">
            Watch Trailer
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <Router>
      <div className="min-h-screen bg-nexus-900 text-gray-100 font-sans selection:bg-nexus-accent selection:text-nexus-900 pb-20 md:pb-0">
        
        {/* Toast Container */}
        <div className="fixed top-24 right-4 z-50 flex flex-col items-end pointer-events-none">
          <div className="pointer-events-auto">
            {toasts.map(toast => (
              <Toast key={toast.id} toast={toast} onClose={removeToast} />
            ))}
          </div>
        </div>

        <Navigation 
          cartCount={cart.reduce((a, b) => a + b.quantity, 0)}
          wishlistCount={wishlist.length}
          onOpenCart={() => setIsCartOpen(true)}
          onOpenProfile={() => setIsProfileOpen(true)}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
        />

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 md:px-8 py-8">
          <Routes>
            <Route path="/" element={
              <>
                <Hero />
                
                <TrendingRow 
                   games={trendingGames} 
                   onAddToCart={addToCart} 
                   onViewDetails={handleViewDetails}
                   isWishlisted={(id) => wishlist.includes(id)}
                   onToggleWishlist={toggleWishlist}
                />

                {/* Categories */}
                <div className="flex overflow-x-auto gap-2 mb-8 pb-2 scrollbar-hide">
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat}
                      onClick={() => handleCategoryChange(cat)}
                      className={`px-6 py-2 rounded-full font-medium whitespace-nowrap transition-all ${
                        selectedCategory === cat 
                        ? 'bg-nexus-accent text-nexus-900 shadow-[0_0_15px_rgba(0,242,255,0.4)] font-bold' 
                        : 'bg-nexus-800 text-gray-400 hover:bg-nexus-700 hover:text-white border border-nexus-700 hover:border-nexus-600'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Games Grid */}
                <h2 className="text-2xl font-display font-bold text-white mb-6">All Games</h2>
                {isGridLoading ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 animate-pulse">
                     {[...Array(8)].map((_, i) => (
                       <GameCardSkeleton key={i} />
                     ))}
                  </div>
                ) : filteredGames.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 animate-slide-up">
                    {filteredGames.map(game => (
                      <GameCard 
                        key={game.id} 
                        game={game} 
                        onAddToCart={addToCart}
                        onViewDetails={handleViewDetails}
                        isWishlisted={wishlist.includes(game.id)}
                        onToggleWishlist={toggleWishlist}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-20 bg-nexus-800/50 rounded-2xl border border-nexus-700/50">
                    <Ghost size={64} className="mx-auto text-nexus-700 mb-4 animate-float" />
                    <h3 className="text-2xl font-bold text-gray-500">No games found</h3>
                    <p className="text-gray-600 mt-2">Try adjusting your search filters or ask our AI assistant.</p>
                  </div>
                )}
                
                <div className="mt-20">
                  <Newsletter />
                </div>
              </>
            } />
            <Route path="/library" element={<Library />} />
            <Route path="/community" element={<Community />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer className="bg-nexus-800 border-t border-nexus-700 py-12 mt-12 mb-16 md:mb-0">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-display font-bold text-white mb-4">NEXUS GAMING</h2>
            <p className="text-gray-500 mb-8 max-w-md mx-auto">
              Your gateway to digital worlds. Built with React, Tailwind, and powered by Gemini AI.
            </p>
            <div className="flex justify-center gap-6 text-gray-400">
               <button onClick={() => setIsAboutOpen(true)} className="hover:text-nexus-accent transition-colors">About</button>
               <a href="#" className="hover:text-nexus-accent transition-colors">Terms</a>
               <a href="#" className="hover:text-nexus-accent transition-colors">Privacy</a>
               <a href="#" className="hover:text-nexus-accent transition-colors">Support</a>
            </div>
            <div className="mt-8 text-xs text-nexus-700">
              © 2024 Nexus Gaming. All rights reserved.
            </div>
          </div>
        </footer>

        {/* Global Components */}
        <CartDrawer 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)} 
          cart={cart} 
          onRemove={removeFromCart} 
        />
        
        <AIChatAssistant />
        
        <GameDetailsModal 
          game={activeGame} 
          isLoading={isDetailsLoading}
          onClose={handleCloseDetails} 
          onAddToCart={addToCart}
          reviews={activeGameReviews}
          onAddReview={handleAddReview}
        />
        
        <AboutModal 
          isOpen={isAboutOpen}
          onClose={() => setIsAboutOpen(false)}
        />

        <ProfileModal 
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
        />

      </div>
    </Router>
  );
};

export default App;