import React from 'react';
import { MessageSquare, Heart, Share2, MoreHorizontal, User } from 'lucide-react';

export const Community: React.FC = () => {
  const posts = [
    {
      id: 1,
      user: "NeonRunner",
      avatar: "N",
      time: "2 hours ago",
      content: "Just discovered a secret area in Cyber Odyssey 2077! Has anyone else found the underground neural network hub? The loot there is insane.",
      image: "https://image.pollinations.ai/prompt/cyberpunk%20secret%20underground%20base%20neon?width=800&height=400&nologo=true",
      likes: 245,
      comments: 42
    },
    {
      id: 2,
      user: "TacticalGamer",
      avatar: "T",
      time: "5 hours ago",
      content: "Looking for a squad for Warfront: Tactics ranked matches. Must have mic and know the Bravo map callouts. DM me!",
      likes: 89,
      comments: 15
    },
    {
      id: 3,
      user: "PixelArtist",
      avatar: "P",
      time: "1 day ago",
      content: "Working on some fan art for Pixel Knights. Here is a WIP of the main character.",
      image: "https://image.pollinations.ai/prompt/pixel%20art%20fan%20art%20knight%20character?width=800&height=400&nologo=true",
      likes: 562,
      comments: 78
    }
  ];

  return (
    <div className="max-w-4xl mx-auto animate-slide-up">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-display font-bold text-white mb-2">Community Hub</h1>
          <p className="text-gray-400">Join the conversation, share clips, and find your squad.</p>
        </div>
        <button className="bg-nexus-purple hover:bg-nexus-purple/80 text-white px-6 py-2.5 rounded-lg font-bold transition-colors shadow-lg shadow-nexus-purple/20">
          New Post
        </button>
      </div>

      <div className="flex gap-8">
        {/* Main Feed */}
        <div className="flex-1 space-y-6">
          {posts.map(post => (
            <div key={post.id} className="bg-nexus-800 border border-nexus-700 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-nexus-700 flex items-center justify-center font-bold text-white border border-nexus-600">
                    {post.avatar}
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm">{post.user}</h3>
                    <p className="text-xs text-gray-500">{post.time}</p>
                  </div>
                </div>
                <button className="text-gray-500 hover:text-white">
                  <MoreHorizontal size={20} />
                </button>
              </div>

              <p className="text-gray-300 mb-4 leading-relaxed">{post.content}</p>

              {post.image && (
                <div className="rounded-lg overflow-hidden mb-4 border border-nexus-700/50">
                  <img src={post.image} alt="Post content" className="w-full h-auto" />
                </div>
              )}

              <div className="flex items-center gap-6 pt-4 border-t border-nexus-700/50">
                <button className="flex items-center gap-2 text-gray-400 hover:text-nexus-danger transition-colors group">
                  <Heart size={18} className="group-hover:scale-110 transition-transform" />
                  <span className="text-sm">{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 text-gray-400 hover:text-nexus-accent transition-colors group">
                  <MessageSquare size={18} className="group-hover:scale-110 transition-transform" />
                  <span className="text-sm">{post.comments} Comments</span>
                </button>
                <button className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors ml-auto">
                  <Share2 size={18} />
                  <span className="text-sm">Share</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Sidebar */}
        <div className="hidden lg:block w-80 space-y-6">
          <div className="bg-nexus-800/50 border border-nexus-700 rounded-xl p-5 sticky top-24">
            <h3 className="font-bold text-white mb-4 flex items-center gap-2">
              <User size={18} className="text-nexus-accent" /> Active Users
            </h3>
            <div className="flex flex-wrap gap-2 mb-4">
               {[...Array(12)].map((_, i) => (
                 <div key={i} className="w-8 h-8 rounded-full bg-nexus-700 border border-nexus-600" />
               ))}
               <div className="w-8 h-8 rounded-full bg-nexus-700 border border-nexus-600 flex items-center justify-center text-xs text-gray-400">
                 +2k
               </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-400">#general</span>
                <span className="text-nexus-accent bg-nexus-900 px-2 py-0.5 rounded text-xs">124</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-400">#lfg-ranked</span>
                <span className="text-nexus-accent bg-nexus-900 px-2 py-0.5 rounded text-xs">56</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-400">#tech-support</span>
                <span className="text-nexus-accent bg-nexus-900 px-2 py-0.5 rounded text-xs">12</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};