import React from 'react';
import { Game } from '../types';
import { Play, Clock, Cloud, MoreVertical } from 'lucide-react';
import { MOCK_GAMES } from '../constants';

export const Library: React.FC = () => {
  // Simulating owned games
  const ownedGames = [MOCK_GAMES[0], MOCK_GAMES[2], MOCK_GAMES[5]];

  return (
    <div className="animate-slide-up">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-display font-bold text-white mb-2">My Library</h1>
          <p className="text-gray-400">3 games installed • 125 hours played</p>
        </div>
        <div className="flex gap-2">
           <select className="bg-nexus-800 border border-nexus-700 text-white text-sm rounded-lg p-2.5 focus:ring-nexus-accent focus:border-nexus-accent">
             <option>Recent Activity</option>
             <option>Alphabetical</option>
             <option>Play Time</option>
           </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ownedGames.map(game => (
          <div key={game.id} className="bg-nexus-800 rounded-xl overflow-hidden border border-nexus-700 group hover:border-nexus-accent transition-colors">
            <div className="relative h-48">
              <img src={game.banner} alt={game.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />
              <button className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-16 h-16 bg-nexus-accent rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(0,242,255,0.6)] transform hover:scale-110 transition-transform">
                  <Play size={32} className="text-nexus-900 ml-1" fill="currentColor" />
                </div>
              </button>
            </div>
            
            <div className="p-4">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-bold text-white text-lg">{game.title}</h3>
                <button className="text-gray-400 hover:text-white">
                  <MoreVertical size={20} />
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm text-gray-400 mb-4">
                <div className="flex items-center gap-2">
                  <Clock size={16} className="text-nexus-purple" />
                  <span>42 hrs played</span>
                </div>
                <div className="flex items-center gap-2">
                  <Cloud size={16} className="text-nexus-accent" />
                  <span>Cloud synced</span>
                </div>
              </div>

              <div className="w-full bg-nexus-900 rounded-full h-1.5 mb-2">
                <div className="bg-nexus-accent h-1.5 rounded-full" style={{ width: '65%' }}></div>
              </div>
              <div className="flex justify-between text-xs text-gray-500">
                <span>4/12 Achievements</span>
                <span>35%</span>
              </div>
            </div>
          </div>
        ))}

        {/* Placeholder for empty slot */}
        <div className="border-2 border-dashed border-nexus-700 rounded-xl flex flex-col items-center justify-center p-8 text-gray-500 hover:border-nexus-600 hover:text-gray-400 transition-colors cursor-pointer min-h-[300px]">
           <div className="w-16 h-16 rounded-full bg-nexus-800 flex items-center justify-center mb-4">
             <span className="text-3xl font-light">+</span>
           </div>
           <p className="font-medium">Add Non-Nexus Game</p>
        </div>
      </div>
    </div>
  );
};