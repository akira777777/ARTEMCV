import { Game, Review } from './types';

// Helper to generate consistent AI images based on prompts
const getGameImage = (prompt: string) => 
  `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=400&height=600&nologo=true&seed=${Math.random()}`;

const getBannerImage = (prompt: string) => 
  `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1200&height=600&nologo=true&seed=${Math.random()}`;

export const MOCK_GAMES: Game[] = [
  {
    id: '1',
    title: 'Cyber Odyssey 2077',
    price: 59.99,
    discountPrice: 29.99,
    description: 'An open-world, action-adventure story set in Night City, a megalopolis obsessed with power, glamour and body modification.',
    tags: ['RPG', 'Cyberpunk', 'Open World'],
    rating: 4.8,
    releaseDate: '2023-11-10',
    developer: 'Red Projekt',
    image: 'https://image.pollinations.ai/prompt/cyberpunk%20mercenary%20female%20cyborg%20with%20neon%20katana%20rainy%20futuristic%20city%20street%20night%20highly%20detailed%208k%20cinematic?width=400&height=600&nologo=true',
    banner: 'https://image.pollinations.ai/prompt/panoramic%20cyberpunk%20city%20skyline%20night%20neon%20holograms%20flying%20cars%20futuristic%20cinematic%208k?width=1200&height=600&nologo=true'
  },
  {
    id: '2',
    title: 'Elden Ring: Shadows',
    price: 69.99,
    description: 'Rise, Tarnished, and be guided by grace to brandish the power of the Elden Ring and become an Elden Lord in the Lands Between.',
    tags: ['RPG', 'Souls-like', 'Fantasy'],
    rating: 4.9,
    releaseDate: '2024-02-25',
    developer: 'FromSoft',
    image: 'https://image.pollinations.ai/prompt/dark%20fantasy%20knight%20in%20ornate%20rusted%20armor%20standing%20before%20giant%20glowing%20gold%20erdtree%20mist%20atmospheric%208k?width=400&height=600&nologo=true',
    banner: 'https://image.pollinations.ai/prompt/epic%20dark%20fantasy%20landscape%20ruins%20giant%20glowing%20erdtree%20in%20distance%20fog%20gloomy%20cinematic%20masterpiece?width=1200&height=600&nologo=true'
  },
  {
    id: '3',
    title: 'Stellar Voyager',
    price: 49.99,
    description: 'Explore a procedurally generated galaxy, trade with alien civilizations, and fight in massive fleet battles.',
    tags: ['Space', 'Simulation', 'Strategy'],
    rating: 4.5,
    releaseDate: '2024-01-15',
    developer: 'Cosmic Games',
    image: 'https://image.pollinations.ai/prompt/futuristic%20spaceship%20cockpit%20view%20looking%20at%20colorful%20nebula%20and%20planets%20sci-fi%20highly%20detailed%208k?width=400&height=600&nologo=true',
    banner: 'https://image.pollinations.ai/prompt/epic%20space%20battle%20massive%20capital%20ships%20firing%20lasers%20explosions%20nebula%20background%20cinematic%20sci-fi?width=1200&height=600&nologo=true'
  },
  {
    id: '4',
    title: 'Apex Racer GT',
    price: 39.99,
    description: 'The ultimate racing simulation. Feel the grip, the speed, and the adrenaline of professional GT racing.',
    tags: ['Racing', 'Simulation', 'Sports'],
    rating: 4.2,
    releaseDate: '2023-09-05',
    developer: 'Velocity Studios',
    image: 'https://image.pollinations.ai/prompt/red%20gt3%20race%20car%20speeding%20on%20track%20sunset%20motion%20blur%20photorealistic%20automotive%20photography%208k?width=400&height=600&nologo=true',
    banner: 'https://image.pollinations.ai/prompt/professional%20race%20track%20stadium%20start%20line%20cars%20revving%20crowd%20sunny%20day%20lens%20flare%20cinematic?width=1200&height=600&nologo=true'
  },
  {
    id: '5',
    title: 'Mystery of Blackwood',
    price: 24.99,
    discountPrice: 19.99,
    description: 'A narrative-driven horror game where you must uncover the secrets of an abandoned mansion.',
    tags: ['Horror', 'Adventure', 'Mystery'],
    rating: 4.6,
    releaseDate: '2023-10-31',
    developer: 'Spooky Soft',
    image: 'https://image.pollinations.ai/prompt/creepy%20abandoned%20victorian%20mansion%20at%20night%20lightning%20storm%20silhouette%20ghost%20window%20horror%208k?width=400&height=600&nologo=true',
    banner: 'https://image.pollinations.ai/prompt/dark%20gloomy%20forest%20path%20leading%20to%20haunted%20house%20fog%20moonlight%20horror%20atmosphere%20cinematic?width=1200&height=600&nologo=true'
  },
  {
    id: '6',
    title: 'Pixel Knights',
    price: 14.99,
    description: 'A retro-style 2D platformer with roguelike elements. Fight, die, upgrade, and repeat.',
    tags: ['Indie', 'Platformer', 'Pixel Art'],
    rating: 4.7,
    releaseDate: '2024-03-01',
    developer: 'Indie Devs',
    image: 'https://image.pollinations.ai/prompt/pixel%20art%20fantasy%20knight%20swinging%20sword%20at%20slime%20monster%20retro%2016-bit%20style%20vibrant%20colors?width=400&height=600&nologo=true',
    banner: 'https://image.pollinations.ai/prompt/pixel%20art%20fantasy%20landscape%20castle%20mountains%20clouds%20retro%20game%20background%2016-bit%20style?width=1200&height=600&nologo=true'
  },
   {
    id: '7',
    title: 'Warfront: Tactics',
    price: 34.99,
    description: 'Command your troops in this turn-based strategy game set in a gritty modern warfare setting.',
    tags: ['Strategy', 'Tactical', 'War'],
    rating: 4.3,
    releaseDate: '2023-08-12',
    developer: 'Tactical Minds',
    image: 'https://image.pollinations.ai/prompt/modern%20special%20forces%20soldier%20tactical%20gear%20rifle%20war%20zone%20rubble%20smoke%20realistic%208k%20call%20of%20duty?width=400&height=600&nologo=true',
    banner: 'https://image.pollinations.ai/prompt/modern%20battlefield%20tanks%20helicopters%20soldiers%20smoke%20explosions%20action%20cinematic%20warfare?width=1200&height=600&nologo=true'
  },
  {
    id: '8',
    title: 'Farm Life Simulator',
    price: 29.99,
    description: 'Escape the city and build the farm of your dreams. Grow crops, raise animals, and make friends.',
    tags: ['Simulation', 'Casual', 'Farming'],
    rating: 4.8,
    releaseDate: '2023-05-20',
    developer: 'Green Thumb',
    image: 'https://image.pollinations.ai/prompt/cute%203d%20isometric%20farm%20game%20cows%20chickens%20barn%20vegetable%20garden%20vibrant%20colors%20sunny?width=400&height=600&nologo=true',
    banner: 'https://image.pollinations.ai/prompt/beautiful%20countryside%20landscape%20farm%20house%20windmill%20river%20blue%20sky%20sunny%20day%20cozy%20game%20art?width=1200&height=600&nologo=true'
  }
];

export const CATEGORIES = ['All', 'RPG', 'Action', 'Strategy', 'Simulation', 'Indie', 'Horror', 'Racing'];

export const MOCK_REVIEWS: Review[] = [
  {
    id: '1',
    gameId: '1',
    userName: 'CyberFan99',
    rating: 5,
    comment: 'Absolutely breathtaking visuals. The story gripped me from start to finish.',
    date: '2023-11-12'
  },
  {
    id: '2',
    gameId: '1',
    userName: 'GlitchHunter',
    rating: 4,
    comment: 'Great game, but still a few bugs here and there. Combat is satisfying.',
    date: '2023-11-15'
  },
  {
    id: '3',
    gameId: '2',
    userName: 'TarnishedOne',
    rating: 5,
    comment: 'A masterpiece. Difficult but rewarding.',
    date: '2024-02-26'
  },
  {
    id: '4',
    gameId: '3',
    userName: 'StarCaptain',
    rating: 4,
    comment: 'Deep mechanics, but the learning curve is steep.',
    date: '2024-01-20'
  }
];