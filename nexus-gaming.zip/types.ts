export interface Game {
  id: string;
  title: string;
  price: number;
  discountPrice?: number;
  description: string;
  tags: string[];
  rating: number;
  releaseDate: string;
  developer: string;
  image: string; // Cover image
  banner: string; // Wide image for hero/details
}

export interface CartItem extends Game {
  quantity: number; // Usually 1 for games, but good structure to have
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  isThinking?: boolean;
  sources?: { title: string; uri: string }[];
  media?: {
    type: 'image' | 'video';
    url: string;
  };
}

export type ChatMode = 'chat' | 'think' | 'generate_image' | 'edit_image' | 'analyze_image' | 'animate_image';

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'error';
  message: string;
}

export interface Review {
  id: string;
  gameId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}