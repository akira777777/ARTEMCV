import React from 'react';

// Reusable Shimmer Block Component
const SkeletonBlock = ({ className = "" }: { className?: string }) => (
  <div className={`relative overflow-hidden bg-nexus-700/40 ${className}`}>
    <div className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/5 to-transparent"></div>
  </div>
);

export const GameCardSkeleton = () => {
  return (
    <div className="bg-nexus-800 rounded-xl overflow-hidden border border-nexus-700 h-full flex flex-col">
      {/* Image Placeholder */}
      <SkeletonBlock className="aspect-[3/4] w-full" />
      
      {/* Content */}
      <div className="p-4 space-y-4 flex-1 flex flex-col">
        {/* Title */}
        <SkeletonBlock className="h-6 w-3/4 rounded" />
        
        {/* Rating and Price */}
        <div className="flex justify-between items-center">
          <SkeletonBlock className="h-4 w-1/4 rounded" />
          <SkeletonBlock className="h-6 w-1/5 rounded" />
        </div>

        {/* Buttons */}
        <div className="flex gap-2 pt-2 mt-auto">
           <SkeletonBlock className="h-10 flex-1 rounded" />
           <SkeletonBlock className="h-10 w-10 rounded" />
        </div>
      </div>
    </div>
  );
};

export const GameDetailsSkeleton = () => {
  return (
    <div className="w-full h-full flex flex-col md:flex-row bg-nexus-800">
      {/* Image Section */}
      <SkeletonBlock className="w-full md:w-2/5 h-48 md:h-auto shrink-0" />

      {/* Content Section */}
      <div className="w-full md:w-3/5 p-6 md:p-8 flex flex-col space-y-6">
        {/* Tags */}
        <div className="flex gap-2">
          {[1,2,3].map(i => <SkeletonBlock key={i} className="h-6 w-16 rounded" />)}
        </div>

        {/* Title */}
        <SkeletonBlock className="h-10 w-3/4 rounded" />

        {/* Metadata */}
        <div className="flex gap-6">
          <SkeletonBlock className="h-5 w-20 rounded" />
          <SkeletonBlock className="h-5 w-24 rounded" />
          <SkeletonBlock className="h-5 w-24 rounded" />
        </div>

        {/* Description */}
        <div className="space-y-3">
          <SkeletonBlock className="h-4 w-full rounded" />
          <SkeletonBlock className="h-4 w-full rounded" />
          <SkeletonBlock className="h-4 w-full rounded" />
          <SkeletonBlock className="h-4 w-3/4 rounded" />
        </div>

        {/* Price & Action */}
        <div className="mt-auto p-4 bg-nexus-900/50 rounded-xl border border-nexus-700 flex flex-col sm:flex-row gap-4 justify-between items-center">
          <div className="space-y-2 w-full sm:w-auto">
            <SkeletonBlock className="h-4 w-12 rounded" />
            <SkeletonBlock className="h-8 w-32 rounded" />
          </div>
          <SkeletonBlock className="h-12 w-full sm:w-40 rounded" />
        </div>
      </div>
    </div>
  );
};