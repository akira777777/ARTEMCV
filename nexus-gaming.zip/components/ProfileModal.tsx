import React, { useState, useEffect } from 'react';
import { X, User, Trophy, History, Settings, Lock } from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  const [isClosing, setIsClosing] = useState(false);

  useEffect(() => {
    if (isOpen) setIsClosing(false);
  }, [isOpen]);

  if (!isOpen && !isClosing) return null;

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className={`absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity duration-300 ${isClosing ? 'animate-fade-out' : 'animate-fade-in'}`} 
        onClick={handleClose} 
      />
      
      <div className={`relative w-full max-w-md bg-nexus-800 rounded-2xl overflow-hidden shadow-2xl border border-nexus-700 ${isClosing ? 'animate-zoom-out' : 'animate-zoom-in'}`}>
        <button 
          onClick={handleClose}
          className="absolute top-4 right-4 z-10 p-2 bg-black/50 rounded-full text-white hover:bg-nexus-accent hover:text-nexus-900 transition-colors"
        >
          <X size={20} />
        </button>

        <div className="p-8">
          <div className="flex flex-col items-center mb-8">
             <div className="w-24 h-24 bg-nexus-900 rounded-full flex items-center justify-center border-2 border-nexus-700 mb-4 relative overflow-hidden group">
                <User size={40} className="text-gray-500" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                   <Lock size={20} className="text-white" />
                </div>
             </div>
             <h2 className="text-2xl font-display font-bold text-white">GUEST USER</h2>
             <p className="text-xs text-nexus-accent tracking-widest uppercase mt-1">Not Logged In</p>
          </div>

          <div className="space-y-3 mb-8">
             {[
               { icon: Trophy, label: 'Achievements', desc: 'Track your progress' },
               { icon: History, label: 'Order History', desc: 'View past purchases' },
               { icon: Settings, label: 'Settings', desc: 'Preferences & Security' }
             ].map((item, idx) => (
               <div key={idx} className="flex items-center gap-4 p-3 bg-nexus-900/40 rounded-xl border border-nexus-700/50 opacity-60">
                 <div className="p-2 bg-nexus-800 rounded-lg text-gray-400">
                   <item.icon size={18} />
                 </div>
                 <div className="flex-1">
                   <h4 className="text-sm font-bold text-gray-300">{item.label}</h4>
                   <p className="text-[10px] text-gray-500">{item.desc}</p>
                 </div>
                 <Lock size={14} className="text-nexus-700" />
               </div>
             ))}
          </div>

          <div className="bg-gradient-to-r from-nexus-800 to-nexus-700 border border-nexus-700 p-4 rounded-xl text-center">
             <h3 className="text-sm font-bold text-white mb-1">Coming Soon</h3>
             <p className="text-xs text-gray-400">
               We are building a complete profile system with cloud saves and social features.
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};