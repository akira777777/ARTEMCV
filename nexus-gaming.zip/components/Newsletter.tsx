import React, { useState } from 'react';
import { Mail, ArrowRight, Check } from 'lucide-react';

export const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubscribed(true);
      setEmail('');
      setTimeout(() => setIsSubscribed(false), 3000);
    }
  };

  return (
    <div className="bg-gradient-to-r from-nexus-800 to-nexus-900 rounded-2xl p-8 md:p-12 mb-12 border border-nexus-700 relative overflow-hidden animate-slide-up">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-nexus-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-nexus-purple/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>

      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="max-w-xl">
          <h2 className="text-3xl font-display font-bold text-white mb-3">Don't Miss a Drop</h2>
          <p className="text-gray-400">
            Subscribe to the Nexus newsletter for exclusive deals, new game announcements, and AI-curated recommendations delivered straight to your inbox.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="w-full md:w-auto flex-1 max-w-md">
          <div className="relative group">
            <div className={`absolute -inset-0.5 bg-gradient-to-r from-nexus-accent to-nexus-purple rounded-lg blur opacity-30 group-hover:opacity-75 transition duration-1000 ${isSubscribed ? 'opacity-0' : ''}`}></div>
            <div className="relative flex bg-nexus-900 rounded-lg p-1">
              <div className="pl-3 flex items-center pointer-events-none">
                <Mail className="text-gray-500" size={20} />
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={isSubscribed ? "Thanks for subscribing!" : "Enter your email"}
                disabled={isSubscribed}
                className="bg-transparent border-0 text-white text-sm block w-full p-2.5 focus:ring-0 focus:outline-none placeholder-gray-500"
              />
              <button
                type="submit"
                disabled={isSubscribed}
                className={`flex-shrink-0 text-sm font-bold py-2.5 px-5 rounded-md transition-all duration-300 flex items-center gap-2 ${
                  isSubscribed 
                    ? 'bg-green-500 text-white' 
                    : 'bg-nexus-accent text-nexus-900 hover:bg-nexus-accentHover'
                }`}
              >
                {isSubscribed ? (
                  <>
                    <Check size={16} /> Subscribed
                  </>
                ) : (
                  <>
                    Subscribe <ArrowRight size={16} />
                  </>
                )}
              </button>
            </div>
          </div>
          <p className="mt-3 text-xs text-gray-500 text-center md:text-left">
            We respect your privacy. Unsubscribe at any time.
          </p>
        </form>
      </div>
    </div>
  );
};