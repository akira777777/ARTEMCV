import React, { useState, useEffect } from 'react';
import { X, Cpu, Globe, Shield, Zap } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  const [isClosing, setIsClosing] = useState(false);

  useEffect(() => {
    if (isOpen) setIsClosing(false);
  }, [isOpen]);

  if (!isOpen && !isClosing) return null;

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(onClose, 300); // Match animation duration
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className={`absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity duration-300 ${isClosing ? 'animate-fade-out' : 'animate-fade-in'}`} 
        onClick={handleClose} 
      />
      
      <div className={`relative w-full max-w-2xl bg-nexus-800 rounded-2xl overflow-hidden shadow-2xl border border-nexus-700 ${isClosing ? 'animate-zoom-out' : 'animate-zoom-in'}`}>
        <button 
          onClick={handleClose}
          className="absolute top-4 right-4 z-10 p-2 bg-black/50 rounded-full text-white hover:bg-nexus-accent hover:text-nexus-900 transition-colors"
        >
          <X size={20} />
        </button>

        <div className="p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-display font-bold text-white mb-2">ABOUT NEXUS</h2>
            <div className="h-1 w-20 bg-nexus-accent mx-auto rounded-full"></div>
            <p className="text-gray-400 mt-4 max-w-md mx-auto">
              Redefining digital distribution with immersive design and artificial intelligence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-nexus-700/50 p-4 rounded-xl border border-nexus-700 hover:border-nexus-accent/50 transition-colors">
              <div className="bg-nexus-900 w-10 h-10 rounded-lg flex items-center justify-center mb-3 text-nexus-accent">
                <Globe size={20} />
              </div>
              <h3 className="font-bold text-white mb-2">Our Mission</h3>
              <p className="text-sm text-gray-400">
                To create a seamless, borderless marketplace for gamers worldwide, connecting players with the experiences they crave instantly.
              </p>
            </div>
            
            <div className="bg-nexus-700/50 p-4 rounded-xl border border-nexus-700 hover:border-nexus-accent/50 transition-colors">
              <div className="bg-nexus-900 w-10 h-10 rounded-lg flex items-center justify-center mb-3 text-nexus-purple">
                <Cpu size={20} />
              </div>
              <h3 className="font-bold text-white mb-2">Powered by AI</h3>
              <p className="text-sm text-gray-400">
                Nexus utilizes Google's Gemini models to provide real-time recommendations, chat assistance, and dynamic content generation.
              </p>
            </div>
          </div>

          <div className="bg-nexus-900/50 rounded-xl p-6 border border-nexus-700">
            <h3 className="font-display font-bold text-white mb-4 flex items-center gap-2">
              <Zap size={18} className="text-yellow-400" /> TECH STACK
            </h3>
            <div className="flex flex-wrap gap-2">
              {['React 19', 'TypeScript', 'Tailwind CSS', 'Google Gemini API', 'Vite', 'Lucide Icons'].map((tech) => (
                <span key={tech} className="px-3 py-1 bg-nexus-800 text-gray-300 text-xs font-mono rounded border border-nexus-700">
                  {tech}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-8 text-center text-xs text-gray-500">
            Version 2.0.0-alpha • Built for the future
          </div>
        </div>
      </div>
    </div>
  );
};