import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, X, Bot, Sparkles, ExternalLink, Paperclip, Image as ImageIcon, Video, Brain, Wand2, Edit, ChevronDown } from 'lucide-react';
import { chatWithGemini, chatDeepThink, analyzeImage, generateImage, editImage, animateImage } from '../services/geminiService';
import { ChatMessage, ChatMode } from '../types';

export const AIChatAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', role: 'model', text: "Greetings! I'm Nexus AI. I can help you find games, analyze screenshots, or generate creative content." }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  // Mode State
  const [mode, setMode] = useState<ChatMode>('chat');
  const [showModeSelector, setShowModeSelector] = useState(false);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [genImageSize, setGenImageSize] = useState<'1K' | '2K' | '4K'>('1K');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAttachedFile(e.target.files[0]);
    }
  };

  const handleSend = async () => {
    if ((!input.trim() && !attachedFile) || isTyping) return;

    // Create User Message
    const userMsg: ChatMessage = { 
      id: Date.now().toString(), 
      role: 'user', 
      text: input || (attachedFile ? `[Uploaded: ${attachedFile.name}]` : '')
    };
    setMessages(prev => [...prev, userMsg]);
    
    const currentInput = input;
    const currentFile = attachedFile;
    const currentMode = mode;
    const currentSize = genImageSize;

    // Clear Inputs
    setInput('');
    setAttachedFile(null);
    setIsTyping(true);

    try {
      let response;

      switch (currentMode) {
        case 'think':
          response = await chatDeepThink(currentInput);
          break;
        case 'analyze_image':
          if (!currentFile) {
            response = { text: "Please attach an image to analyze." };
          } else {
            response = await analyzeImage(currentFile, currentInput);
          }
          break;
        case 'generate_image':
          response = await generateImage(currentInput, currentSize);
          break;
        case 'edit_image':
          if (!currentFile) {
            response = { text: "Please attach an image to edit." };
          } else {
            response = await editImage(currentFile, currentInput);
          }
          break;
        case 'animate_image':
          if (!currentFile) {
            response = { text: "Please attach an image to animate." };
          } else {
            response = await animateImage(currentFile);
          }
          break;
        case 'chat':
        default:
          response = await chatWithGemini(currentInput);
          break;
      }

      const botMsg: ChatMessage = { 
        id: (Date.now() + 1).toString(), 
        role: 'model', 
        text: response.text,
        sources: response.sources,
        media: response.media
      };
      
      setMessages(prev => [...prev, botMsg]);
    } catch (e) {
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "Something went wrong. Please try again." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSend();
  };

  const ModeIcon = () => {
    switch (mode) {
      case 'think': return <Brain size={16} className="text-nexus-purple" />;
      case 'generate_image': return <Wand2 size={16} className="text-pink-500" />;
      case 'edit_image': return <Edit size={16} className="text-orange-500" />;
      case 'analyze_image': return <ImageIcon size={16} className="text-blue-500" />;
      case 'animate_image': return <Video size={16} className="text-red-500" />;
      default: return <MessageSquare size={16} className="text-nexus-accent" />;
    }
  };

  const ModeLabel = () => {
    switch (mode) {
      case 'think': return "Deep Think";
      case 'generate_image': return "Generate Image";
      case 'edit_image': return "Edit Image";
      case 'analyze_image': return "Analyze Image";
      case 'animate_image': return "Animate (Veo)";
      default: return "Chat";
    }
  };

  return (
    <>
      {/* Floating Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-40 p-4 rounded-full shadow-lg transition-all duration-300 flex items-center justify-center ${
          isOpen ? 'bg-nexus-700 text-white rotate-90' : 'bg-gradient-to-r from-nexus-purple to-nexus-accent text-white animate-pulse-slow hover:scale-110'
        }`}
      >
        {isOpen ? <X size={24} /> : <MessageSquare size={24} />}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-80 md:w-[400px] bg-nexus-800/95 backdrop-blur-md rounded-2xl shadow-2xl border border-nexus-700 z-40 flex flex-col overflow-hidden max-h-[700px] h-[600px] animate-float">
          {/* Header */}
          <div className="p-4 bg-nexus-900/50 border-b border-nexus-700 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-nexus-accent to-nexus-purple flex items-center justify-center">
                <Bot size={18} className="text-white" />
              </div>
              <div>
                <h3 className="font-display font-bold text-white">Nexus AI</h3>
                <p className="text-xs text-nexus-accent flex items-center gap-1">
                  <Sparkles size={10} /> Online
                </p>
              </div>
            </div>
            
            {/* Mode Selector */}
            <div className="relative">
              <button 
                onClick={() => setShowModeSelector(!showModeSelector)}
                className="flex items-center gap-2 bg-nexus-800 border border-nexus-700 rounded-lg px-3 py-1.5 text-xs font-bold text-white hover:border-nexus-accent transition-colors"
              >
                <ModeIcon />
                <span><ModeLabel /></span>
                <ChevronDown size={12} />
              </button>

              {showModeSelector && (
                <div className="absolute right-0 top-full mt-2 w-48 bg-nexus-800 border border-nexus-700 rounded-xl shadow-xl overflow-hidden z-50">
                   {[
                     { m: 'chat', label: 'Chat', icon: MessageSquare, color: 'text-nexus-accent' },
                     { m: 'think', label: 'Deep Think', icon: Brain, color: 'text-nexus-purple' },
                     { m: 'generate_image', label: 'Generate Image', icon: Wand2, color: 'text-pink-500' },
                     { m: 'edit_image', label: 'Edit Image', icon: Edit, color: 'text-orange-500' },
                     { m: 'analyze_image', label: 'Analyze Image', icon: ImageIcon, color: 'text-blue-500' },
                     { m: 'animate_image', label: 'Animate (Veo)', icon: Video, color: 'text-red-500' },
                   ].map((item) => (
                     <button
                       key={item.m}
                       onClick={() => { setMode(item.m as ChatMode); setShowModeSelector(false); }}
                       className="w-full text-left px-4 py-3 text-xs text-white hover:bg-nexus-700 flex items-center gap-3"
                     >
                       <item.icon size={14} className={item.color} />
                       {item.label}
                     </button>
                   ))}
                </div>
              )}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map(msg => (
              <div 
                key={msg.id} 
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div 
                  className={`max-w-[90%] p-3 rounded-2xl text-sm ${
                    msg.role === 'user' 
                    ? 'bg-nexus-accent text-nexus-900 font-medium rounded-tr-none' 
                    : 'bg-nexus-700 text-gray-200 rounded-tl-none'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{msg.text}</div>
                  
                  {/* Media Display */}
                  {msg.media && (
                    <div className="mt-3 rounded-lg overflow-hidden border border-nexus-600">
                      {msg.media.type === 'image' ? (
                        <img src={msg.media.url} alt="Generated" className="w-full h-auto" />
                      ) : (
                        <video controls src={msg.media.url} className="w-full h-auto" />
                      )}
                    </div>
                  )}
                </div>
                
                {/* Sources Display */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-2 max-w-[85%] flex flex-wrap gap-2">
                    {msg.sources.slice(0, 3).map((source, idx) => (
                      <a 
                        key={idx}
                        href={source.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-[10px] bg-nexus-900/80 border border-nexus-700 px-2 py-1 rounded-full text-gray-400 hover:text-nexus-accent hover:border-nexus-accent transition-colors"
                      >
                        <ExternalLink size={8} />
                        <span className="truncate max-w-[100px]">{source.title}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-nexus-700 p-3 rounded-2xl rounded-tl-none flex gap-1">
                  <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                  <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-75" />
                  <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-150" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 bg-nexus-900/50 border-t border-nexus-700">
            {/* File Attachment Preview */}
            {attachedFile && (
              <div className="mb-2 px-3 py-2 bg-nexus-800 rounded-lg flex justify-between items-center text-xs text-gray-300 border border-nexus-700">
                <span className="truncate max-w-[200px]">{attachedFile.name}</span>
                <button onClick={() => setAttachedFile(null)} className="text-gray-500 hover:text-white">
                  <X size={14} />
                </button>
              </div>
            )}

            {/* Configs (e.g. Size selector for Gen Image) */}
            {mode === 'generate_image' && (
              <div className="flex gap-2 mb-2 px-1">
                 {['1K', '2K', '4K'].map((size) => (
                   <button
                     key={size}
                     onClick={() => setGenImageSize(size as any)}
                     className={`text-[10px] px-2 py-1 rounded border ${genImageSize === size ? 'bg-nexus-accent text-nexus-900 border-nexus-accent' : 'bg-transparent text-gray-400 border-nexus-700'}`}
                   >
                     {size}
                   </button>
                 ))}
              </div>
            )}

            <div className="relative flex gap-2">
              {/* Attachment Button (Only for relevant modes) */}
              {['edit_image', 'analyze_image', 'animate_image'].includes(mode) && (
                <>
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    accept="image/*"
                    className="hidden"
                  />
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="p-3 bg-nexus-800 border border-nexus-700 rounded-full text-gray-400 hover:text-white transition-colors"
                  >
                    <Paperclip size={18} />
                  </button>
                </>
              )}

              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder={
                  mode === 'generate_image' ? "Describe the image..." :
                  mode === 'edit_image' ? "Describe changes..." :
                  mode === 'animate_image' ? "Upload image to animate..." :
                  "Type a message..."
                }
                disabled={mode === 'animate_image'} // Animate only takes image
                className="flex-1 bg-nexus-900 border border-nexus-700 rounded-full py-3 px-4 pr-12 text-sm text-white focus:outline-none focus:border-nexus-accent placeholder-gray-500 disabled:opacity-50"
              />
              
              <button 
                onClick={handleSend}
                disabled={isTyping || (!input && !attachedFile && mode !== 'animate_image')}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-nexus-700 rounded-full text-nexus-accent hover:bg-nexus-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};