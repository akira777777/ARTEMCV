import React, { useEffect } from 'react';
import { CheckCircle, Info, AlertCircle, X } from 'lucide-react';
import { ToastMessage } from '../types';

interface ToastProps {
  toast: ToastMessage;
  onClose: (id: string) => void;
}

export const Toast: React.FC<ToastProps> = ({ toast, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose(toast.id);
    }, 3000);
    return () => clearTimeout(timer);
  }, [toast.id, onClose]);

  const icons = {
    success: <CheckCircle size={20} className="text-nexus-accent" />,
    info: <Info size={20} className="text-nexus-purple" />,
    error: <AlertCircle size={20} className="text-nexus-danger" />
  };

  const borders = {
    success: 'border-nexus-accent',
    info: 'border-nexus-purple',
    error: 'border-nexus-danger'
  };

  return (
    <div className={`flex items-center gap-3 bg-nexus-800 border-l-4 ${borders[toast.type]} text-white px-4 py-3 rounded shadow-lg min-w-[300px] animate-slide-in mb-2`}>
      {icons[toast.type]}
      <p className="flex-1 text-sm font-medium">{toast.message}</p>
      <button onClick={() => onClose(toast.id)} className="text-gray-400 hover:text-white">
        <X size={16} />
      </button>
    </div>
  );
};
