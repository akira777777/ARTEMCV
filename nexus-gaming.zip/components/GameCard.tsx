import React from 'react';
import { Game } from '../types';
import { Plus, Star, Info, Heart } from 'lucide-react';

interface GameCardProps {
  game: Game;
  onAddToCart: (game: Game) => void;
  onViewDetails: (game: Game) => void;
  isWishlisted: boolean;
  onToggleWishlist: (game: Game) => void;
}

export const GameCard: React.FC<GameCardProps> = ({ 
  game, 
  onAddToCart, 
  onViewDetails, 
  isWishlisted, 
  onToggleWishlist 
}) => {
  return (
    // Outer Wrapper: Handles Positioning, Hover State, z-index stacking
    <div className="group relative h-full hover:-translate-y-2 transition-transform duration-300 hover:z-20">
      
      {/* Tooltip */}
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 -translate-y-full w-72 p-4 bg-nexus-800/95 backdrop-blur-xl rounded-xl border border-nexus-700/80 shadow-[0_10px_40px_rgba(0,0,0,0.5)] opacity-0 group-hover:opacity-100 transition-all duration-300 delay-100 pointer-events-none invisible group-hover:visible z-30">
        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-nexus-800 border-r border-b border-nexus-700/80 rotate-45 transform"></div>
        <div className="relative z-10">
          <h4 className="font-display font-bold text-white mb-2 text-sm flex items-center gap-2 uppercase tracking-wider">
            <span className="w-1.5 h-1.5 bg-nexus-accent rounded-full shadow-[0_0_8px_rgba(0,242,255,0.8)]"></span>
            Overview
          </h4>
          <p className="text-gray-400 text-xs leading-relaxed font-sans line-clamp-6">
            {game.description}
          </p>
          <div className="mt-3 flex gap-2">
            {game.tags.slice(0, 3).map(tag => (
              <span key={tag} className="text-[10px] px-2 py-1 bg-nexus-900 rounded border border-nexus-700 text-nexus-accent">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Main Card Content */}
      <div className="relative bg-nexus-800 rounded-xl overflow-hidden border border-nexus-700 group-hover:border-nexus-accent group-hover:shadow-[0_0_20px_rgba(0,242,255,0.3)] transition-all duration-300 h-full">
        {/* Image Area */}
        <div className="relative aspect-[3/4] overflow-hidden cursor-pointer" onClick={() => onViewDetails(game)}>
          <img 
            src={game.image} 
            alt={game.title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-nexus-900 via-transparent to-transparent opacity-80" />
          
          {/* Wishlist Button */}
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(game);
            }}
            className="absolute top-2 left-2 p-2 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-sm transition-all z-20 group/btn"
          >
            <Heart 
              size={18} 
              className={`transition-colors duration-300 ${isWishlisted ? 'text-nexus-danger fill-nexus-danger' : 'text-white group-hover/btn:scale-110'}`} 
            />
          </button>

          {/* Discount Badge */}
          {game.discountPrice && (
            <div className="absolute top-2 right-2 bg-nexus-danger text-white text-xs font-bold px-2 py-1 rounded shadow-lg">
              -{Math.round(((game.price - game.discountPrice) / game.price) * 100)}%
            </div>
          )}
        </div>

        {/* Card Info */}
        <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-2 group-hover:translate-y-0 transition-transform duration-300 bg-gradient-to-t from-nexus-900 via-nexus-900/90 to-transparent pt-12">
          <h3 className="text-lg font-display font-bold text-white truncate mb-1">{game.title}</h3>
          
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-1 text-yellow-400">
              <Star size={14} fill="currentColor" />
              <span className="text-sm font-medium">{game.rating}</span>
            </div>
            <div className="text-right">
               {game.discountPrice ? (
                  <>
                    <span className="text-nexus-danger font-bold text-lg">${game.discountPrice}</span>
                    <span className="text-gray-500 text-xs line-through ml-2">${game.price}</span>
                  </>
               ) : (
                  <span className="text-nexus-accent font-bold text-lg">${game.price}</span>
               )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pt-2">
            <button 
              onClick={() => onAddToCart(game)}
              className="flex-1 bg-nexus-accent hover:bg-nexus-accentHover text-nexus-900 font-bold py-2 rounded flex items-center justify-center gap-1 text-sm transition-colors shadow-lg shadow-nexus-accent/20"
            >
              <Plus size={16} /> Add
            </button>
            <button 
               onClick={() => onViewDetails(game)}
               className="bg-nexus-700 hover:bg-nexus-600 text-white p-2 rounded transition-colors border border-nexus-600"
            >
              <Info size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};