import React, { useState, useEffect } from 'react';
import { X, ShoppingCart, Star, Calendar, User, MessageSquare, Send } from 'lucide-react';
import { Game, Review } from '../types';
import { GameDetailsSkeleton } from './Skeletons';

interface GameDetailsModalProps {
  game: Game | null;
  isLoading?: boolean;
  onClose: () => void;
  onAddToCart: (game: Game) => void;
  reviews: Review[];
  onAddReview: (gameId: string, review: Omit<Review, 'id' | 'gameId' | 'date'>) => void;
}

export const GameDetailsModal: React.FC<GameDetailsModalProps> = ({ 
  game, 
  isLoading = false,
  onClose, 
  onAddToCart,
  reviews,
  onAddReview
}) => {
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [userName, setUserName] = useState('');
  const [isClosing, setIsClosing] = useState(false);

  // Reset closing state when game opens
  useEffect(() => {
    if (game || isLoading) setIsClosing(false);
  }, [game, isLoading]);

  // Handle Internal Close with Animation
  const handleClose = () => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  };

  const handleAddToCart = (g: Game) => {
    onAddToCart(g);
    handleClose();
  };

  if ((!game && !isLoading) && !isClosing) return null;

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !game) return;

    onAddReview(game.id, {
      userName: userName.trim() || 'Anonymous Gamer',
      rating: newRating,
      comment: newComment
    });

    setNewComment('');
    setUserName('');
    setNewRating(5);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className={`absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity duration-300 ${isClosing ? 'animate-fade-out' : 'animate-fade-in'}`} 
        onClick={handleClose} 
      />
      
      <div className={`relative w-full max-w-4xl bg-nexus-800 rounded-2xl overflow-hidden shadow-2xl border border-nexus-700 flex flex-col md:flex-row max-h-[90vh] ${isClosing ? 'animate-zoom-out' : 'animate-zoom-in'}`}>
        <button 
          onClick={handleClose}
          className="absolute top-4 right-4 z-10 p-2 bg-black/50 rounded-full text-white hover:bg-nexus-accent hover:text-nexus-900 transition-colors"
        >
          <X size={20} />
        </button>

        {isLoading ? (
          <GameDetailsSkeleton />
        ) : game ? (
          <>
            {/* Image Section (Desktop: Left Side, Mobile: Top) */}
            <div className="w-full md:w-2/5 h-48 md:h-auto relative shrink-0">
              <img src={game.image} alt={game.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-nexus-900 to-transparent md:bg-gradient-to-r" />
            </div>

            {/* Content Section (Scrollable) */}
            <div className="w-full md:w-3/5 p-6 md:p-8 overflow-y-auto flex flex-col">
              <div className="mb-2 flex items-center gap-2">
                {game.tags.map(tag => (
                  <span key={tag} className="px-2 py-1 bg-nexus-700 text-nexus-accent text-xs rounded uppercase font-bold tracking-wider">
                    {tag}
                  </span>
                ))}
              </div>
              
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">{game.title}</h2>
              
              <div className="flex items-center gap-6 mb-6 text-gray-300 text-sm">
                 <div className="flex items-center gap-1">
                   <Star className="text-yellow-400" size={16} />
                   <span className="font-bold text-white">{game.rating}</span>/5
                 </div>
                 <div className="flex items-center gap-1">
                   <Calendar className="text-nexus-accent" size={16} />
                   <span>{game.releaseDate}</span>
                 </div>
                 <div className="flex items-center gap-1">
                   <User className="text-nexus-accent" size={16} />
                   <span>{game.developer}</span>
                 </div>
              </div>

              <p className="text-gray-300 leading-relaxed mb-8">
                {game.description}
              </p>

              <div className="flex items-center justify-between p-4 bg-nexus-900/50 rounded-xl border border-nexus-700 mb-8">
                 <div className="flex flex-col">
                   <span className="text-sm text-gray-400">Price</span>
                   <div className="flex items-baseline gap-2">
                      {game.discountPrice ? (
                        <>
                           <span className="text-3xl font-bold text-nexus-danger">${game.discountPrice}</span>
                           <span className="text-lg text-gray-500 line-through">${game.price}</span>
                        </>
                      ) : (
                        <span className="text-3xl font-bold text-nexus-accent">${game.price}</span>
                      )}
                   </div>
                 </div>
                 <button 
                   onClick={() => handleAddToCart(game)}
                   className="bg-nexus-accent hover:bg-nexus-accentHover text-nexus-900 px-6 py-3 rounded-lg font-bold flex items-center gap-2 transition-all hover:shadow-[0_0_20px_rgba(0,242,255,0.4)]"
                 >
                   <ShoppingCart size={20} /> Add to Cart
                 </button>
              </div>

              {/* Reviews Section */}
              <div className="border-t border-nexus-700 pt-6">
                <h3 className="text-xl font-display font-bold text-white mb-4 flex items-center gap-2">
                  <MessageSquare className="text-nexus-purple" size={20} /> Reviews
                </h3>

                {/* Review List */}
                <div className="space-y-4 mb-8">
                  {reviews.length === 0 ? (
                    <p className="text-gray-500 italic">No reviews yet. Be the first to review!</p>
                  ) : (
                    reviews.map(review => (
                      <div key={review.id} className="bg-nexus-700/30 p-4 rounded-lg border border-nexus-700/50">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-nexus-600 flex items-center justify-center text-xs font-bold text-white">
                              {review.userName.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-bold text-sm text-white">{review.userName}</p>
                              <div className="flex text-yellow-400">
                                {[...Array(5)].map((_, i) => (
                                  <Star key={i} size={10} fill={i < review.rating ? "currentColor" : "none"} className={i < review.rating ? "" : "text-gray-600"} />
                                ))}
                              </div>
                            </div>
                          </div>
                          <span className="text-xs text-gray-500">{review.date}</span>
                        </div>
                        <p className="text-gray-300 text-sm">{review.comment}</p>
                      </div>
                    ))
                  )}
                </div>

                {/* Write Review Form */}
                <form onSubmit={handleSubmitReview} className="bg-nexus-900/50 p-4 rounded-xl border border-nexus-700">
                  <h4 className="font-bold text-white mb-3 text-sm">Write a Review</h4>
                  
                  <div className="flex items-center gap-4 mb-3">
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          type="button"
                          key={star}
                          onClick={() => setNewRating(star)}
                          className="focus:outline-none transition-transform hover:scale-110"
                        >
                          <Star 
                            size={20} 
                            className={star <= newRating ? "text-yellow-400 fill-yellow-400" : "text-gray-600"} 
                          />
                        </button>
                      ))}
                    </div>
                    <input 
                      type="text" 
                      placeholder="Your Name (Optional)" 
                      value={userName}
                      onChange={(e) => setUserName(e.target.value)}
                      className="flex-1 bg-nexus-800 border border-nexus-700 rounded px-3 py-1.5 text-sm text-white focus:border-nexus-accent focus:outline-none"
                    />
                  </div>

                  <div className="flex gap-2">
                    <textarea
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Share your thoughts about this game..."
                      className="flex-1 bg-nexus-800 border border-nexus-700 rounded p-3 text-sm text-white focus:border-nexus-accent focus:outline-none resize-none h-20"
                    />
                    <button 
                      type="submit"
                      disabled={!newComment.trim()}
                      className="bg-nexus-purple hover:bg-nexus-accent hover:text-nexus-900 text-white px-4 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                      <Send size={18} />
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
};