import React from 'react';
import { Game } from '../types';
import { Flame, ChevronRight } from 'lucide-react';
import { GameCard } from './GameCard';

interface TrendingRowProps {
  games: Game[];
  onAddToCart: (game: Game) => void;
  onViewDetails: (game: Game) => void;
  isWishlisted: (id: string) => boolean;
  onToggleWishlist: (game: Game) => void;
}

export const TrendingRow: React.FC<TrendingRowProps> = ({ 
  games, 
  onAddToCart, 
  onViewDetails, 
  isWishlisted, 
  onToggleWishlist 
}) => {
  return (
    <div className="mb-12 animate-slide-up">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-display font-bold text-white flex items-center gap-2">
          <Flame className="text-nexus-danger" /> Trending Now
        </h2>
        <button className="text-nexus-accent hover:text-white text-sm font-bold flex items-center gap-1 transition-colors">
          View All <ChevronRight size={16} />
        </button>
      </div>
      
      <div className="flex gap-6 overflow-x-auto pb-6 scrollbar-hide snap-x">
        {games.map(game => (
          <div key={game.id} className="min-w-[280px] md:min-w-[300px] snap-start">
            <GameCard 
              game={game}
              onAddToCart={onAddToCart}
              onViewDetails={onViewDetails}
              isWishlisted={isWishlisted(game.id)}
              onToggleWishlist={onToggleWishlist}
            />
          </div>
        ))}
      </div>
    </div>
  );
};