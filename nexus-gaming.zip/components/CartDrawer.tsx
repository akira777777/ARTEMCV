import React from 'react';
import { X, Trash2, ShoppingBag } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onRemove: (id: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, cart, onRemove }) => {
  const total = cart.reduce((sum, item) => sum + (item.discountPrice || item.price) * item.quantity, 0);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      {/* Drawer */}
      <div className="relative w-full max-w-md bg-nexus-800 h-full shadow-2xl flex flex-col border-l border-nexus-700 transform transition-transform duration-300 animate-slide-in">
        <div className="p-5 border-b border-nexus-700 flex items-center justify-between">
          <h2 className="text-xl font-display font-bold flex items-center gap-2">
            <ShoppingBag className="text-nexus-accent" /> Your Cart
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {cart.length === 0 ? (
            <div className="text-center text-gray-500 mt-10">
              <p>Your cart is empty.</p>
              <p className="text-sm mt-2">Go find some loot!</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.id} className="flex gap-4 bg-nexus-700/50 p-3 rounded-lg border border-nexus-700/50 hover:border-nexus-600 transition-colors">
                <img src={item.image} alt={item.title} className="w-16 h-20 object-cover rounded" />
                <div className="flex-1">
                  <h4 className="font-bold text-sm text-gray-200 line-clamp-1">{item.title}</h4>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-nexus-accent font-bold">
                      ${(item.discountPrice || item.price).toFixed(2)}
                    </span>
                    <button 
                      onClick={() => onRemove(item.id)}
                      className="text-gray-400 hover:text-nexus-danger transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-5 border-t border-nexus-700 bg-nexus-800">
          <div className="flex justify-between items-center mb-4">
            <span className="text-gray-400">Total</span>
            <span className="text-2xl font-display font-bold text-white">${total.toFixed(2)}</span>
          </div>
          <button 
            disabled={cart.length === 0}
            className={`w-full py-3 rounded font-bold text-nexus-900 transition-all ${
              cart.length === 0 
              ? 'bg-gray-600 cursor-not-allowed' 
              : 'bg-nexus-accent hover:bg-nexus-accentHover hover:shadow-[0_0_15px_rgba(0,242,255,0.4)]'
            }`}
          >
            Checkout
          </button>
        </div>
      </div>
    </div>
  );
};
